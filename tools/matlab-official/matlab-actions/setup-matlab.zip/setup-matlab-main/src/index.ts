// Copyright 2020-2026 The MathWorks, Inc.

import * as core from "@actions/core";
import * as install from "./install.js";

/**
 * Gather action inputs and then run action.
 */
export async function run() {
    const platform = process.platform;
    const architecture = process.arch;
    const release = core.getInput("release");
    const products = core.getMultilineInput("products");
    const cache = core.getBooleanInput("cache");
    const installSystemDependencies = core.getInput("install-system-dependencies");

    return install.install(
        platform,
        architecture,
        release,
        products,
        cache,
        installSystemDependencies,
    );
}

run().catch((e) => {
    core.setFailed(e);
});
