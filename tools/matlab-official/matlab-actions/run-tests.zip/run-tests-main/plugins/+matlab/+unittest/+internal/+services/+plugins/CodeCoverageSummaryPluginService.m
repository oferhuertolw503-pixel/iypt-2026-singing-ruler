classdef CodeCoverageSummaryPluginService < matlab.buildtool.internal.services.ciplugins.CITestRunnerPluginService
    % Copyright 2026 The MathWorks, Inc.
    
    methods
        function plugins = providePlugins(~, ~)
            verInfo = ver;
            productNames = string({verInfo.Name});
            productName = 'MATLAB Test';
            isProductInstalled = any(productNames.matches(productName));
            hasCoverageHTML = ~isempty(getenv('INPUT_CODE_COVERAGE_HTML'));
            hasCoverageCobertura = ~isempty(getenv('INPUT_CODE_COVERAGE_COBERTURA'));
            hasCoverageRequest = hasCoverageHTML || hasCoverageCobertura;

            % Check if MATLAB Test license is available and MATLAB Test is installed
            if license('test', 'matlab_test') && isProductInstalled && ~hasCoverageRequest
                % Get metric level from environment variable
                metricLevel = getenv('INPUT_CODE_COVERAGE_METRIC_LEVEL');

                % Create a shared CoverageResult format object
                format = matlab.unittest.plugins.codecoverage.CoverageResult;
                
                % Create an array to hold multiple plugins
                plugins = matlab.unittest.plugins.TestRunnerPlugin.empty(0);
                
                % Get source folder from environment variable
                sourceFolder = getenv('INPUT_SOURCE_FOLDER');
                if isempty(sourceFolder)
                    sourceFolder = pwd;
                end
                
                coveragePlugin = matlab.unittest.plugins.CodeCoveragePlugin.forFolder(...
                    sourceFolder, 'Producing', format, 'MetricLevel', metricLevel);

                plugins(end+1) = coveragePlugin;
                
                % Add the summary plugin with the same format object
                summaryPlugin = testframework.CodeCoverageSummaryPlugin(format, metricLevel);
                plugins(end+1) = summaryPlugin;
            else
                plugins = matlab.unittest.plugins.TestRunnerPlugin.empty(1,0);
            end
        end
    end
end
