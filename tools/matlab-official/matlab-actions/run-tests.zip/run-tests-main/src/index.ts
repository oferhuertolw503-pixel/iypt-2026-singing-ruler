// Copyright 2020-2026 The MathWorks, Inc.

import * as core from "@actions/core";
import * as exec from "@actions/exec";
import * as scriptgen from "./scriptgen.js";
import { matlab, testResultsSummary } from "common-utils";

/**
 * Gather action inputs and then run action
 */
async function run() {
    const platform = process.platform;
    const architecture = process.arch;
    const workspaceDir = process.cwd();

    const options: scriptgen.RunTestsOptions = {
        JUnitTestResults: core.getInput("test-results-junit"),
        CoberturaCodeCoverage: core.getInput("code-coverage-cobertura"),
        HTMLCodeCoverage: core.getInput("code-coverage-html"),
        SourceFolder: core.getInput("source-folder"),
        PDFTestReport: core.getInput("test-results-pdf"),
        HTMLTestReport: core.getInput("test-results-html"),
        SimulinkTestResults: core.getInput("test-results-simulink-test"),
        CoberturaModelCoverage: core.getInput("model-coverage-cobertura"),
        HTMLModelCoverage: core.getInput("model-coverage-html"),
        SelectByTag: core.getInput("select-by-tag"),
        SelectByFolder: core.getInput("select-by-folder"),
        Strict: core.getBooleanInput("strict"),
        UseParallel: core.getBooleanInput("use-parallel"),
        OutputDetail: core.getInput("output-detail"),
        LoggingLevel: core.getInput("logging-level"),
    };

    var codeCoverageMetricLevel = core.getInput("code-coverage-metric-level").toLowerCase();

    // Validate metric level
    const validMetricLevels = ["statement", "decision", "condition", "mcdc"];
    if (!validMetricLevels.includes(codeCoverageMetricLevel)) {
        core.warning(
            `Invalid metric level '${codeCoverageMetricLevel}'. Using the default value ('mcdc') instead.`,
        );
        codeCoverageMetricLevel = "mcdc";
    }

    const command = scriptgen.generateCommand(options);
    const startupOptions = core.getInput("startup-options").split(" ");

    const helperScript = await matlab.generateScript(workspaceDir, command);
    const execOptions = {
        env: {
            ...process.env,
            MW_BATCH_LICENSING_ONLINE: "true", // Remove when online batch licensing is the default
            INPUT_CODE_COVERAGE_METRIC_LEVEL: codeCoverageMetricLevel,
            INPUT_SOURCE_FOLDER: options.SourceFolder!, // Add source folder to environment
            INPUT_CODE_COVERAGE_HTML: options.HTMLCodeCoverage!,
            INPUT_CODE_COVERAGE_COBERTURA: options.CoberturaCodeCoverage!,
        },
    };
    core.info("Successfully generated test script!");

    await matlab
        .runCommand(
            helperScript,
            platform,
            architecture,
            (cmd, args) => exec.exec(cmd, args, execOptions),
            startupOptions,
        )
        .finally(() => {
            const runnerTemp = process.env.RUNNER_TEMP || "";
            const runId = process.env.GITHUB_RUN_ID || "";

            //add test results and code coverage view
            testResultsSummary.processAndAddTestSummary(runnerTemp, runId, workspaceDir);
            core.summary.write();
        });
}

run().catch((e) => {
    core.setFailed(e);
});
