// Copyright 2025-2026 The MathWorks, Inc.

package evalmatlabcode_test

import (
	"testing"

	"github.com/matlab/matlab-mcp-core-server/internal/adaptors/mcp/tools/annotations"
	"github.com/matlab/matlab-mcp-core-server/internal/adaptors/mcp/tools/multisession/evalmatlabcode"
	"github.com/matlab/matlab-mcp-core-server/internal/entities"
	"github.com/matlab/matlab-mcp-core-server/internal/messages"
	"github.com/matlab/matlab-mcp-core-server/internal/testutils"
	evalmatlabcodeusecase "github.com/matlab/matlab-mcp-core-server/internal/usecases/evalmatlabcode"
	configmocks "github.com/matlab/matlab-mcp-core-server/mocks/adaptors/application/config"
	basetoolsmocks "github.com/matlab/matlab-mcp-core-server/mocks/adaptors/mcp/tools/basetool"
	mocks "github.com/matlab/matlab-mcp-core-server/mocks/adaptors/mcp/tools/multisession/evalmatlabcode"
	entitiesmocks "github.com/matlab/matlab-mcp-core-server/mocks/entities"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNew_HappyPath(t *testing.T) {
	// Arrange
	mockLoggerFactory := &basetoolsmocks.MockLoggerFactory{}
	defer mockLoggerFactory.AssertExpectations(t)

	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	// Act
	tool := evalmatlabcode.New(mockLoggerFactory, mockConfigFactory, mockUsecase, mockMATLABManager)

	// Assert
	assert.NotNil(t, tool)
}

func TestTool_Handler_HappyPath(t *testing.T) {
	// Arrange
	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockConfig := &configmocks.MockConfig{}
	defer mockConfig.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockMATLABSessionClient := &entitiesmocks.MockMATLABSessionClient{}
	defer mockMATLABSessionClient.AssertExpectations(t)

	mockLogger := testutils.NewInspectableLogger()
	ctx := t.Context()
	const sessionID = 123
	const code = "disp('Hello, World!')"
	const projectPath = "/some/path"
	shouldShowMATLABDesktop := true
	expectedResponse := entities.EvalResponse{
		ConsoleOutput: "Hello, World!",
		Images:        [][]byte{[]byte("image1"), []byte("image2")},
	}
	args := evalmatlabcode.Args{
		SessionID:   sessionID,
		Code:        code,
		ProjectPath: projectPath,
	}

	mockConfigFactory.EXPECT().
		Config().
		Return(mockConfig, nil).
		Once()

	mockConfig.EXPECT().
		ShouldShowMATLABDesktop().
		Return(shouldShowMATLABDesktop).
		Once()

	mockMATLABManager.EXPECT().
		GetMATLABSessionClient(ctx, mockLogger.AsMockArg(), entities.SessionID(sessionID)).
		Return(mockMATLABSessionClient, nil).
		Once()

	mockUsecase.EXPECT().
		Execute(
			ctx,
			mockLogger.AsMockArg(),
			mockMATLABSessionClient,
			evalmatlabcodeusecase.Args{
				Code:          code,
				ProjectPath:   projectPath,
				CaptureOutput: !shouldShowMATLABDesktop,
			},
		).
		Return(expectedResponse, nil).
		Once()

	// Act
	result, err := evalmatlabcode.Handler(mockConfigFactory, mockUsecase, mockMATLABManager)(ctx, mockLogger, args)

	// Assert
	require.NoError(t, err, "Handler should not return an error")

	require.Len(t, result.TextContent, 1, "Should have one text content item")
	assert.Equal(t, expectedResponse.ConsoleOutput, result.TextContent[0], "Text content should match")

	require.Len(t, result.ImageContent, 2, "Should have two image content items")
	assert.Equal(t, "image1", string(result.ImageContent[0]), "First image should match")
	assert.Equal(t, "image2", string(result.ImageContent[1]), "Second image should match")
}

func TestTool_Handler_GetMATLABSessionClientErrors(t *testing.T) {
	// Arrange
	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockConfig := &configmocks.MockConfig{}
	defer mockConfig.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockMATLABSessionClient := &entitiesmocks.MockMATLABSessionClient{}
	defer mockMATLABSessionClient.AssertExpectations(t)

	mockLogger := testutils.NewInspectableLogger()
	ctx := t.Context()
	const sessionID = 123
	const code = "invalid code"
	const projectPath = "/some/path"
	expectedError := assert.AnError
	args := evalmatlabcode.Args{
		SessionID:   sessionID,
		Code:        code,
		ProjectPath: projectPath,
	}

	mockConfigFactory.EXPECT().
		Config().
		Return(mockConfig, nil).
		Once()

	mockMATLABManager.EXPECT().
		GetMATLABSessionClient(ctx, mockLogger.AsMockArg(), entities.SessionID(sessionID)).
		Return(nil, expectedError).
		Once()

	// Act
	result, err := evalmatlabcode.Handler(mockConfigFactory, mockUsecase, mockMATLABManager)(ctx, mockLogger, args)

	// Assert
	require.ErrorIs(t, err, expectedError, "Handler should return an error")
	assert.Empty(t, result, "Result should be empty in an error case")
}

func TestTool_Handler_UsecaseReturnsError(t *testing.T) {
	// Arrange
	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockConfig := &configmocks.MockConfig{}
	defer mockConfig.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockMATLABSessionClient := &entitiesmocks.MockMATLABSessionClient{}
	defer mockMATLABSessionClient.AssertExpectations(t)

	mockLogger := testutils.NewInspectableLogger()
	ctx := t.Context()
	const sessionID = 123
	const code = "invalid code"
	const projectPath = "/some/path"
	shouldShowMATLABDesktop := true
	expectedError := assert.AnError
	args := evalmatlabcode.Args{
		SessionID:   sessionID,
		Code:        code,
		ProjectPath: projectPath,
	}

	mockConfigFactory.EXPECT().
		Config().
		Return(mockConfig, nil).
		Once()

	mockConfig.EXPECT().
		ShouldShowMATLABDesktop().
		Return(shouldShowMATLABDesktop).
		Once()

	mockMATLABManager.EXPECT().
		GetMATLABSessionClient(ctx, mockLogger.AsMockArg(), entities.SessionID(sessionID)).
		Return(mockMATLABSessionClient, nil).
		Once()

	mockUsecase.EXPECT().
		Execute(
			ctx,
			mockLogger.AsMockArg(),
			mockMATLABSessionClient,
			evalmatlabcodeusecase.Args{
				Code:          code,
				ProjectPath:   projectPath,
				CaptureOutput: !shouldShowMATLABDesktop,
			},
		).
		Return(entities.EvalResponse{}, expectedError).
		Once()

	// Act
	result, err := evalmatlabcode.Handler(mockConfigFactory, mockUsecase, mockMATLABManager)(ctx, mockLogger, args)

	// Assert
	require.ErrorIs(t, err, expectedError, "Handler should return an error")
	assert.Empty(t, result, "Result should be empty in an error case")
}

func TestTool_Handler_UsecaseReturnsEmptyResponse(t *testing.T) {
	// Arrange
	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockConfig := &configmocks.MockConfig{}
	defer mockConfig.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockMATLABSessionClient := &entitiesmocks.MockMATLABSessionClient{}
	defer mockMATLABSessionClient.AssertExpectations(t)

	mockLogger := testutils.NewInspectableLogger()
	ctx := t.Context()
	const sessionID = 123
	const code = "% Empty comment"
	const projectPath = "/some/path"
	shouldShowMATLABDesktop := true
	emptyResponse := entities.EvalResponse{
		ConsoleOutput: "",
		Images:        nil,
	}
	args := evalmatlabcode.Args{
		SessionID:   sessionID,
		Code:        code,
		ProjectPath: projectPath,
	}

	mockConfigFactory.EXPECT().
		Config().
		Return(mockConfig, nil).
		Once()

	mockConfig.EXPECT().
		ShouldShowMATLABDesktop().
		Return(shouldShowMATLABDesktop).
		Once()

	mockMATLABManager.EXPECT().
		GetMATLABSessionClient(ctx, mockLogger.AsMockArg(), entities.SessionID(sessionID)).
		Return(mockMATLABSessionClient, nil).
		Once()

	mockUsecase.EXPECT().
		Execute(
			ctx,
			mockLogger.AsMockArg(),
			mockMATLABSessionClient,
			evalmatlabcodeusecase.Args{
				Code:          code,
				ProjectPath:   projectPath,
				CaptureOutput: !shouldShowMATLABDesktop,
			},
		).
		Return(emptyResponse, nil).
		Once()

	// Act
	result, err := evalmatlabcode.Handler(mockConfigFactory, mockUsecase, mockMATLABManager)(ctx, mockLogger, args)

	// Assert
	require.NoError(t, err, "Handler should not return an error")

	require.Len(t, result.TextContent, 1, "Should have one text content item")
	assert.Empty(t, result.TextContent[0], "Text content should be empty")
	assert.Empty(t, result.ImageContent, "Image content should be empty")
}

func TestTool_Handler_ConfigError(t *testing.T) {
	// Arrange
	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockLogger := testutils.NewInspectableLogger()
	ctx := t.Context()
	expectedError := messages.New_StartupErrors_BadFlag_Error("flag", "value", "reason")
	args := evalmatlabcode.Args{
		SessionID:   123,
		Code:        "disp('test')",
		ProjectPath: "/some/path",
	}

	mockConfigFactory.EXPECT().
		Config().
		Return(nil, expectedError).
		Once()

	// Act
	result, err := evalmatlabcode.Handler(mockConfigFactory, mockUsecase, mockMATLABManager)(ctx, mockLogger, args)

	// Assert
	require.ErrorIs(t, err, expectedError, "Handler should return the config error")
	assert.Empty(t, result, "Result should be empty in an error case")
}

func TestEvalInMATLABSession_Annotations(t *testing.T) {
	// Arrange
	mockLoggerFactory := &basetoolsmocks.MockLoggerFactory{}
	defer mockLoggerFactory.AssertExpectations(t)

	mockConfigFactory := &mocks.MockConfigFactory{}
	defer mockConfigFactory.AssertExpectations(t)

	mockMATLABManager := &entitiesmocks.MockMATLABManager{}
	defer mockMATLABManager.AssertExpectations(t)

	mockUsecase := &mocks.MockUsecase{}
	defer mockUsecase.AssertExpectations(t)

	expectedAnnotations := annotations.NewDestructiveAnnotations()

	// Act
	tool := evalmatlabcode.New(mockLoggerFactory, mockConfigFactory, mockUsecase, mockMATLABManager)

	// Assert
	assert.Equal(t, expectedAnnotations, tool.Annotations(), "Tool should have destructive annotations")
}
